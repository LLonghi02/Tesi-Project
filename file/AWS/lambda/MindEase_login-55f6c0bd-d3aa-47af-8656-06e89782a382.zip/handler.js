const connect_to_db = require('./db');
const talk = require('./Talk');

module.exports.MindEase_login = (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    console.log('Received event:', JSON.stringify(event, null, 2));
    let body = {};
    if (event.body) {
        body = JSON.parse(event.body);
    }

    // Validazione dei dati di input
    if (!body.nickname || !body.password) {
        return callback(null, {
            statusCode: 400,
            headers: { 'Content-Type': 'text/plain' },
            body: 'Missing nickname or password.'
        });
    }

    connect_to_db().then(() => {
        console.log('=> get_all talks');
        talk.findOne({ "nickname": body.nickname, "password": body.password })
            .then(user => {
                if (!user) {
                    console.log('=> User not found');
                    return callback(null, {
                        statusCode: 404,
                        headers: { 'Content-Type': 'text/plain' },
                        body: 'User not found.'
                    });
                }
                console.log('=> User found:', user);
                callback(null, {
                    statusCode: 200,
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({"Message": "Success", "nickname": user.nickname, "password": user.password, })
                });
            })
            .catch(err => {
                console.error('Database query failed:', err);
                callback(null, {
                    statusCode: 500,
                    headers: { 'Content-Type': 'text/plain' },
                    body: 'Could not fetch the user. ' + err.message
                });
            });
    }).catch(err => {
        console.error('Database connection failed:', err);
        callback(null, {
            statusCode: 500,
            headers: { 'Content-Type': 'text/plain' },
            body: 'Database connection failed. ' + err.message
        });
    });
};
