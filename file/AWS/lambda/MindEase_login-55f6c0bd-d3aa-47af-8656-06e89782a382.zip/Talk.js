const mongoose = require('mongoose');

const talk_schema = new mongoose.Schema({
    _id: String,
    email: String,
    nickname: String,
    password: String,
}, { collection: 'Utenti_registrati' });

module.exports = mongoose.model('talk', talk_schema);