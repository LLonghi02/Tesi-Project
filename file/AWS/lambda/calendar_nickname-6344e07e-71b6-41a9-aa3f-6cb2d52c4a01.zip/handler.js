const connect_to_db = require('./db');
const user = require('./user');

module.exports.calendar_nickname = (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    console.log('Received event:', JSON.stringify(event, null, 2));
    let body = {};
    if (event.body) {
        body = JSON.parse(event.body);
    }
    // set default
    if (!body.Nickname) {
        callback(null, {
            statusCode: 500,
            headers: { 'Content-Type': 'text/plain' },
            body: 'Nickname is null.'
        });
        return;
    }

    connect_to_db().then(() => {
        console.log('=> Querying database for nickname:', body.Nickname);
        user.find({ 
            Nickname: body.Nickname
        }).then(users => {
            // Map users to include only required fields
            const formattedUsers = users.map(user => ({
                Data: user.Data,
                Emozione: user.Emozione,
                Causa: user.Causa,
                Sintomi: user.Sintomi
            }));

            // Respond with formatted data
            callback(null, {
                statusCode: 200,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formattedUsers)
            });
        }).catch(err => {
            console.error('Error fetching users:', err);
            callback(null, {
                statusCode: err.statusCode || 500,
                headers: { 'Content-Type': 'text/plain' },
                body: 'Could not fetch the users.'
            });
        });
    }).catch(err => {
        console.error('Database connection error:', err);
        callback(null, {
            statusCode: err.statusCode || 500,
            headers: { 'Content-Type': 'text/plain' },
            body: 'Could not connect to the database.'
        });
    });
};
