const mongoose = require('mongoose');

const videoSchema = new mongoose.Schema({
    _id: String,
    Data: String,
    Emozione: String,
    Causa: String,
    Sintomi: [String] ,
    Nickname: String,
}, { collection: 'Calendar_Emotions_DB' });

module.exports = mongoose.model('video', videoSchema);
