const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    _id: String,
    email: String,
    nickname: String,
    password: String,

}, { collection: 'Utenti_registrati' });

module.exports = mongoose.model('user', userSchema);
