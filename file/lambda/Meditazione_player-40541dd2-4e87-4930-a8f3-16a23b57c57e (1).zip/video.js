const mongoose = require('mongoose');

const videoSchema = new mongoose.Schema({
    _id: String,
    Title: String,
    Author: String,
    DurationSeconds: String,
    VideoURL: String,
    Tag: String,
}, { collection: 'MindEase_meditazione' });

module.exports = mongoose.model('video', videoSchema);
