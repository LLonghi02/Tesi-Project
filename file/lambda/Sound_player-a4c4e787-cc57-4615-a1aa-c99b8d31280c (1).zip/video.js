const mongoose = require('mongoose');

const videoSchema = new mongoose.Schema({
    _id: String,
    Title: String,
    Artist: String, 
    Album: String,
    DurationSeconds: Number, 
    TrackURL: String, 
    Tag: String,
}, { collection: 'MindEase_suoni' });

module.exports = mongoose.model('video', videoSchema);
