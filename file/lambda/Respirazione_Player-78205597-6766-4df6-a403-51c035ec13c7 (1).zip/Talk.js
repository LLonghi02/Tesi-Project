const mongoose = require('mongoose');

const talkSchema = new mongoose.Schema({
    _id: String,
    Title: String,
    Author: String,
    DurationSeconds: String,
    VideoURL: String,
    Tag: String,
}, { collection: 'MindEase_Respirazione' });

module.exports = mongoose.model('Talk', talkSchema);
